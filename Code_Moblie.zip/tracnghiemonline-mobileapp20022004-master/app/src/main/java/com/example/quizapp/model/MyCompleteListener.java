package com.example.quizapp.model;

public interface MyCompleteListener {
    void onSuccess();
    void onFailure();
}
